#include <bits/stdc++.h>
#define int ll

using namespace std;
using ll = long long;
using ld = long double;

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int n, q;
    cin >> n >> q;
    vector<pair<int, int>> a(n);
    vector<ld> r;
    vector<ld> l;
    set<ld> ind;
    map<int, int> le;
    map<int, int> ri;
    for (int i = 0; i < n; i++) {
        cin >> a[i].first >> a[i].second;
        r.push_back(a[i].second);
        ind.insert(a[i].first);
        ind.insert(a[i].second);
        ind.insert(a[i].first - 0.1);
        ind.insert(a[i].second - 0.1);
        ind.insert(a[i].first + 0.1);
        ind.insert(a[i].second + 0.1);
        le[a[i].first]++;
        ri[a[i].second]++;
        l.push_back(a[i].first);
    }
    sort(l.begin(), l.end());
    sort(r.begin(), r.end());
    vector<pair<int, int>> t;
    for (auto u : ind) {
        int cl = lower_bound(r.begin(), r.end(), u) - r.begin();
        int cr = n - (upper_bound(l.begin(), l.end(), u) - l.begin());
        t.push_back({n - cl - cr, min(cl, cr) * 2});
    }
    sort(t.rbegin(), t.rend());
    vector<int> ans(q);
    vector<pair<int, int>> qu(q);
    int k;
    for (int i = 0; i < q; i++) {
        cin >> qu[i].first;
        qu[i].second = i;
    }
    sort(qu.begin(), qu.end());
    int j = 0;
    for (int i = 0; i < q; i++) {
        while ((qu[i].first - t[j].first) > t[j].second) {
            j++;
        }
        ans[qu[i].second] = max((qu[i].first - t[j].first + 1) / 2, 0ll);
    }
    for (auto u : ans) {
        cout << u << " ";
    }
    return 0;
}